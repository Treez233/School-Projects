package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import photomanager.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void testPhotoConsAndtoString() {
		String photoSource = "umcp/college15.jpg", date = "10/18/2030-18:10";
		int width = 800, height = 800;

		Photo photo = new Photo(photoSource, width, height, date);
		System.out.println(photo);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testCons() {
		new Photo("umcp/college51.jpg", -1, 400, "10/18/2020-17:10");
	}

	@Test
	public void testPhotoGetMethods() {
		String photoSource = "umcp/college51.jpg", date = "10/18/2030-18:11";
		int width = 690, height = 640;

		Photo photo = new Photo(photoSource, width, height, date);
		String info = photo.getPhotoSource() + "," + photo.getWidth() + "," + photo.getHeight() + ","
				+ photo.getComments();
		System.out.println(info);
	}

	@Test
	public void testAddandGetComments() {
		String photoSource = "umcp/college51.jpg", date = "10/18/2030-18:11";
		int width = 690, height = 640;

		Photo photo = new Photo(photoSource, width, height, date);
		System.out.println(photo);
		System.out.println("Comments: " + photo.getComments());
		photo.addComments("Buffalo New York");
		System.out.println("Comments: " + photo.getComments());
		photo.addComments("Mayor India Walton");
		System.out.println("Comments: " + photo.getComments());

	}

	@Test
	public void testCopyCons() {

		Photo photo = new Photo("umcp/college51.jpg", 400, 400, "10/18/2030-18:11");
		System.out.println(photo);
		Photo copy = new Photo(photo);
		System.out.println(copy);
	}

	@Test
	public void testcompareTo() {

		Photo photo1 = new Photo("umcp/college51.jpg", 400, 400, "10/18/2030-18:11");
		Photo photo2 = new Photo("umcp/college51.jpg", 400, 400, "10/18/2030-18:12");
		Photo photo3 = new Photo("umcp/college51.jpg", 400, 400, "10/18/2030-18:13");
		System.out.println(photo1);
		System.out.println(photo2);
		System.out.println(photo3);

		System.out.println(photo1.compareTo(photo3) < 0);
		System.out.println(photo1.compareTo(photo2) < 0);
		System.out.println(photo2.compareTo(photo1) > 0);
		System.out.println(photo2.compareTo(photo2) == 0);

	}

	@Test
	public void testAddPhoto() {

		PhotoManager photoManager = new PhotoManager();
		System.out.println("before: \n" + photoManager);
		photoManager.addPhoto("umcp/college1.jpg", 300, 400, "09/21/2020-16:17");
		photoManager.addPhoto("umcp/college8.jpg", 200, 200, "10/30/2020-18:11");

		System.out.println("after: \n" + photoManager);
	}

	@Test
	public void testAddPhotoException() {

		PhotoManager photoManager = new PhotoManager();

		boolean added = photoManager.addPhoto("", 300, 400, "10/30/2020-18:11");
		assertFalse(added);
	}

	@Test
	public void testFindRemove() {
		PhotoManager photoManager = new PhotoManager();
		String target = "umcp/college0.jpg";
		photoManager.addPhoto("umcp/college1.jpg", 300, 400, "09/21/2020-16:18");
		photoManager.addPhoto("umcp/college9.jpg", 300, 400, "09/21/2020-16:20");
		photoManager.addPhoto("umcp/college3.jpg", 300, 400, "09/21/2020-16:07");
		photoManager.addPhoto(target, 300, 400, "09/21/2020-18:17");

		System.out.println("Before Removing: \n" + photoManager);
		System.out.println("Removing: " + target + " at index: " + photoManager.findPhoto(target) + "\n");
		photoManager.removePhoto(target);
		System.out.println("Removed: \n" + photoManager);
	}

	@Test
	public void testLoadandRemoveAll() {
		PhotoManager photoManager = new PhotoManager();

		System.out.println("Before Photos are loaded: \n" + photoManager);
		photoManager.loadPhotos("photoInfoToLoad.txt");
		System.out.println("After Photos are Loaded: \n" + photoManager);
		photoManager.removeAllPhotos();
		System.out.println("After Photos are removed: \n" + photoManager);
	}

	@Test
	public void testSorting() {
		PhotoManager photoManager = new PhotoManager();
		photoManager.loadPhotos("photoInfoToLoad.txt");
		System.out.println("Before Photos are Sorted: \n" + photoManager);
		photoManager.sortPhotosByDate();
		System.out.println("After Photos are Sorted: \n" + photoManager);
	}

}