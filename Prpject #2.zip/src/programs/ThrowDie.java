package programs;

import java.util.Scanner;
import java.util.Random;

public class ThrowDie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		//variables for seed and number of times 
		int seed, num;
		
		//ask the user for input and store it in num
		System.out.print("How many times to throw a die?: ");
		num = scanner.nextInt();
		
		//ask the user for input and store it in seed
		System.out.print("Enter seed: ");
		seed = scanner.nextInt();
		
		//creating a Random object
		Random random = new Random(seed);
		//set the upper bound
		final int DIEBOUND = 6;
		//for loop for the die throws
		for(int i = 0; i < num; i++) {
			
			//title for each throw
			System.out.println("Throw #" + (i+1));
			int number = random.nextInt(DIEBOUND);
			//display the die face
			if((number + 1) == 1) {
				System.out.println("...\n.0.\n...");
			}else if((number +1) == 2) {
				System.out.println("0..\n...\n..0");
			}else if((number +1) == 3) {
				System.out.println("0..\n.0.\n..0");
			}else if((number +1) == 4) {
				System.out.println("0.0\n...\n0.0");
			}else if((number +1) == 5) {
				System.out.println("0.0\n.0.\n0.0");
			}else if((number +1) == 6) {
				System.out.println("0.0\n0.0\n0.0");
			}
			
		}
		
		scanner.close();
	}

}
