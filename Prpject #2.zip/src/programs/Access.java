package programs;

import java.util.Scanner;

public class Access {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		//creating password variables
		String password = "", correctPassword = "terps";
		//creating number variables
		int num, correctNum = 1847;
		//boolean for the while loop
		boolean credentials = false;
		//variable for number of attempt
		int numAttempt = 0;
		
		//while loop for user input
		while (!credentials || numAttempt < 3) {

			//prompt for user to enter the password
			System.out.print("Enter password: ");
			//store the input
			password = scanner.next();

			//if else statement if the user types quit
			if (password.equals("quit")) {
				
				credentials = true;
				//output the error message
				System.out.println("Access Denied");
				//end the loop
				break;
			} else {
				
				//prompt the user to enter the password
				System.out.print("Enter number: ");
				num = scanner.nextInt();
				
				//increase the number of attempt by one
				numAttempt++;
				//if else statements for input validation
				if (password.equals(correctPassword) && num == correctNum) {
					//if the user enter the password and number correctly
					credentials = true;
					//display the message
					System.out.println("Access Granted");
					break;
				} else if (numAttempt == 3) {
					//if the number of attempt is 3
					credentials = true;
					//display the error message
					System.out.println("Wrong credentials");
					System.out.println("Access Denied");
				} else {
					//display the error message
					System.out.println("Wrong credentials");
				}
			}

		}

		scanner.close();
	}

}
