package programs;

import java.util.Scanner;

public class Convert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// constant for base 8
		final int BASE = 8;

		// creating a new scanner
		Scanner scanner = new Scanner(System.in);

		// variables for conversion
		int decimal;
		int remainder;
		String octal = "";

		// ask user for input
		System.out.print("Enter decimal number: ");
		// storing the input into the decimal variable
		decimal = scanner.nextInt();
		
		if (decimal <= 0) {
			octal = octal + decimal;
			System.out.println("Octal value: " + octal);
		} else if (decimal > 0){
			// while loop for the conversion it will loop until the decimal is 0
			while (decimal > 0) {
				// calculate the remainder and assign it
				remainder = decimal % BASE;
				// add the remainder to the string octal
				octal = remainder + octal;
				// assign the value after the division to decimal
				decimal = decimal / BASE;
			}
			// print the result after conversion
			System.out.println("Octal value: " + octal);
		}

		// close the scanner
		scanner.close();
	}

}
