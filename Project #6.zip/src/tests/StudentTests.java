package tests;

import static org.junit.Assert.*;


import org.junit.Test;

import sysImplementation.Utilities;

public class StudentTests {

	@Test //test for the getArrayString method
	public void testgetArrayString() {
		int[] array = {4,5,9,12,7};
		
		String result = Utilities.getArrayString(array, ',');
		String expectedResult = "4,5,9,12,7";
		assertTrue(TestsSupport.sameContents(result, expectedResult));
	}
	@Test //test the getArrayString method with an empty array
	public void testgetArrayStringEmptyArray() {
		int[] array = {};
		
		String result = Utilities.getArrayString(array, ',');
		String expectedResult = "";
		assertTrue(TestsSupport.sameContents(result, expectedResult));
	}
	@Test (expected = IllegalArgumentException.class) //test getArrayString method's exception handling
	public void testgetArrayStringException() {
		Utilities.getArrayString(null, ',');
	}
	@Test //test getInstances method
	public void testgetInstances() {
		int[] array = {4,5,9,12,7,6,13,8,72};
		
		int result = Utilities.getInstances(array, 4, 9);
		System.out.println(result);
		int expected = 6;
		int result1 = Utilities.getInstances(array, 10, 9);
		assertTrue(result == expected);
		assertTrue(result1 == 0 );
	}
	@Test (expected = IllegalArgumentException.class) //test getInstances method exception handling
	public void testgetInstancesException() {
		Utilities.getInstances(null, 1,7);
	}
	@Test
	public void testFilter() { //test Filter methods
		int[] array = {4,5,9,12,7};
		int[] newArray = Utilities.filter(array, 4, 9);
		int[] expected = {4,5,9,7};
		assertTrue(TestsSupport.sameContents(Utilities.getArrayString(newArray, ',')
											,Utilities.getArrayString(expected, ',')));
	}
	@Test (expected = IllegalArgumentException.class)//test Filter methods exception handling with null array
	public void testFilterException1(){
		Utilities.filter(null, 4, 5);
	}
	@Test (expected = IllegalArgumentException.class)//test Filter methods exception handling with lowerLimit greater than upperLimit
	public void testFilterException2(){
		int[] array = {4,5,9,12,7};
		Utilities.filter(array, 9, 5);
	}
	@Test
	public void testLeftRotate() { // test rotate method with left rotation
		int[] array = {4,5,9,12,7};
		
		Utilities.rotate(array,true,16);
		String result = Utilities.getArrayString(array,',');
		System.out.println(result);
		String expected = "5,9,12,7,4";
		assertTrue(result.equals(expected));
	}
	
	@Test
	public void testRightRotate() { // test rotate method with right rotation
		int[] array = {4,5,9,12,7};
		
		Utilities.rotate(array,false,8);
		String result = Utilities.getArrayString(array,',');
		System.out.println(result);
		String expected = "9,12,7,4,5";
		assertTrue(result.equals(expected));
	}
	
	@Test (expected = IllegalArgumentException.class) //test rotate method exception handling
	public void testRotateException(){
		Utilities.rotate(null, false, 5);
	}
	@Test 
	public void testRotateArrayLengthLessThan2(){ // test rotate method with an array with one element
		int[] array = {4};
		String result = Utilities.getArrayString(array,',');
		String expected = "4";
		System.out.println(result);
		assertTrue(result.equals(expected));
	}
	@Test
	public void testgetArrayStringsLongerThan() { //test getArrayStringLongerThan
		StringBuffer resultString = new StringBuffer();
		StringBuffer expectedString = new StringBuffer();
		
		StringBuffer[] array = { new StringBuffer("Cats"), 
								 new StringBuffer("Dogs"), 
								 new StringBuffer("Turtles"),
								 new StringBuffer("Squirrels"), 
								 new StringBuffer("Rabbits") };

		StringBuffer[] newArray = { new StringBuffer("Turtles"), 
									new StringBuffer("Squirrels"),
									new StringBuffer("Rabbits") };
		StringBuffer[] result = Utilities.getArrayStringsLongerThan(array, 4);
		for(StringBuffer animals: newArray) {
			resultString.append(animals);
		}
		for(StringBuffer animals: result) {
			expectedString.append(animals);
		}
		assertTrue(resultString.toString().equals(expectedString.toString()));
		
	}
	
	@Test (expected = IllegalArgumentException.class)//test getArrayStringLongerThan exception handling
	public void testArrayStringLongerException(){
		Utilities.getArrayStringsLongerThan(null, 4);
	}
}
