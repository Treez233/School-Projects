package sysImplementation;

public class Utilities {
	public static java.lang.String getArrayString(int[] array, char separator) {
		String arrayString = ""; //create an empty string
		if (array == null ) { //check the array parameter for exceptions
			throw new IllegalArgumentException();
		}
		//create an integer for the length of the array
		int length = array.length;
		if(length !=0) { // check if the array is empty or not
			for (int number : array) { // for loop to add each element to a string
				//using Integer.toString method to turn an integer into a string
				arrayString += Integer.toString(number) + separator;
			}
			//get rid of the separator 
			arrayString = arrayString.substring(0, arrayString.length() - 1);
			
		}else {
			//if the array is empty return the empty string
			return arrayString;
		}
		//return the finished string
		return arrayString;

	}

	public static int getInstances(int[] array, int lowerLimit, int upperLimit) {
		//integer variable for the number of values to return
		int numberOfValue = 0;
		if (array == null) {//check for exceptions
			throw new IllegalArgumentException();
		}
		//inhanced for loop to loop through the array
		for (int num : array) {
			if (num >= lowerLimit && num <= upperLimit) { //check for the correct range
				//increment the number of values that are in range
				numberOfValue++;
			}
		}
		//return the value 
		return numberOfValue;
	}

	public static int[] filter(int[] array, int lowerLimit, int upperLimit) {
		//check for exceptions
		if (array == null || lowerLimit > upperLimit) {
			throw new IllegalArgumentException();
		}
		//create a new array and use the getInstances method to determine the size
		int[] newArray = new int[Utilities.getInstances(array, lowerLimit, upperLimit)];
		//int variable for the indices
		int index = 0;
		//enhanced for loop to loop through the array
		for (int num : array) {
			if (num >= lowerLimit && num <= upperLimit) {// check if they are in range
				//add the number to the correct index in the new array
				newArray[index] = num;
				//increment the index
				index++;
			}
		}
		//return the new Array
		return newArray;
	}

	public static void rotate(int[] array, boolean leftRotation, int position) {
		//check for exceptions
		if (array == null) {
			throw new IllegalArgumentException();
		}
		//check if the array need to be rotated (have more than 2 elements)
		if (array.length >= 2) {
			for(int i = 0; i < position; i++ ) {//for loop for the number of rotations we need to do
				if(leftRotation) {//check if it's left or right rotation
					//call the leftRotation private method
					leftRotation(array);
				}else {
					//call the rightRotation private method
					rightRotation(array);
				}
			}
		}
	}
	
	//privcate method for rotation to the left
	private static void leftRotation(int[] array) {
		int index; //int variabls for the indices
		int num = array[0]; //store the first element
		for (index = 0; index < array.length - 1; index++) {// start from the 0 end when index reaches the length -1
			//assign the value after the index to the current index
			array[index] = array[index + 1];
		}
		//assign the first element to the last index position
		array[index] = num;

	}
	//privcate method for rotation to the right
	private static void rightRotation(int[] array) {
		int index;//int variabls for the indices
		int num = array[array.length -1]; //store the last element
		for (index = array.length -1; index > 0; index--) { //start from the back end at 0
			//assign the value before the index to the current index
			array[index] = array[index - 1];
		}
		//assign the last element to the first index position
		array[0] = num;
	}

	public static java.lang.StringBuffer[] getArrayStringsLongerThan(java.lang.StringBuffer[] array, int length) {
		//check for exceptions
		if (array == null) {
			throw new IllegalArgumentException();
		}
		//create a new StringBuffer array
		StringBuffer[] greaterArray = new StringBuffer[array.length];
		int j = 0;//int variable for the index of the new StringBuffer Array
		for (int i = 0; i < array.length; i++) { //for loop to loop through the parameter array
			if (array[i].length() > length) {/*check if the length of the StringBuffer a
												at current index is grater than the length passed in*/
				greaterArray[j] = array[i]; //assign the StringBuffer to the new array
				j++; //increment the index of the new array
			}
		}
		
		int newSize = 0; // int for the array size
		//loop through the array to find the elements that is not null
		for (StringBuffer longWord : greaterArray) {
			if (longWord != null) {
				newSize++; 
			}
		}
		//create a new array with the correct size
		StringBuffer[] finalArray = new StringBuffer[newSize];
		//loop through the array and assign each non-null element to the final array
		for (int i = 0; i < newSize; i++) {
			finalArray[i] = greaterArray[i];
		}
		//return the array with the correct size;
		return finalArray;

	}

}