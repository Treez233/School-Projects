package programs;

import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		/* Write your program here */
		//creating a new scanner
		Scanner input = new Scanner(System.in);

		//creating variables for base height and the area
		int base, height;
		double Area;
		
		//ask user for the base
		System.out.print("Enter base: ");
		//store the user input into the integer base
		base = input.nextInt();
		
		//ask user for the height
		System.out.print("Enter height: ");
		//store the user input into the integer height
		height = input.nextInt();
		
		//calculate area
		Area = (height * base) / 2.0;
		
		//output the area
		System.out.println("Area is: " + Area);
		
		//close the scanner
		input.close();
	}
}