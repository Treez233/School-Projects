package programs;

import java.util.Scanner;

public class ColorGenerator {

	public static void main(String[] args) {
		/* Write your program here */
		//creating a new scanner
		Scanner input = new Scanner(System.in);
		
		//creating strings for the output resutls
		String red = "#FF0000", greenBlue = "#00FFFF", white = "#FFFFFF", black = "#000000", answer1, answer2;
		
		//asking the user for input
		System.out.print("Do you want red? (Yes/Yeah/No): ");
		//storing the input into the answer1 string variable
		answer1 = input.nextLine();
		
		//asking the user for input
		System.out.print("Do you want green and blue? (Yes/Yeah/No): ");
		//storing the input into the answer1 string variable
		answer2 = input.nextLine();
		
		//if else statements to display result                              
		if((answer1.equals("Yes") && answer2.equals("No")) || (answer1.equals("Yeah") && answer2.equals("No"))) {
			System.out.println("Final Color: " + red);
		}else if ((answer1.equals("No") && answer2.equals("Yes")) || (answer1.equals("No") && answer2.equals("Yeah"))) {
			System.out.println("Final Color: " + greenBlue);
		}else if ((answer1.equals("Yes") || answer1.equals("Yeah")) && (answer2.equals("Yes")) || answer2.equals("Yeah")) {
			System.out.println("Final Color: " + white);
		}else if (answer1.equals("No") && answer2.equals("No")) {
			System.out.println("Final Color: " + black);
		}
		
		
		
		//close the scanner
		input.close();
	}

}