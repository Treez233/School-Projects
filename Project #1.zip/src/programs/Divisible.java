package programs;
import java.util.Scanner;

public class Divisible {

	public static void main(String[] args) {
		/* Write your program here */
		
		//creating a new scanner
		Scanner input = new Scanner(System.in);
		
		int intX, intY, remainder;
		
		//ask user for the x
		System.out.print("Enter x: ");
		//store the user input into the integer intX
		intX = input.nextInt();
		
		//ask user for the y
		System.out.print("Enter y: ");
		//store the user input into the integer intY
		intY = input.nextInt();
		
		//calculate remainder
		remainder = intX % intY;
		//output the remainder
		System.out.println("Remainder: " + remainder);
		
		//if else statement for the message
		if(remainder != 0) {
			System.out.println(intX + " is NOT divisible by " + intY);
		}else {
			System.out.println(intX + " is divisible by " + intY);
		}
		
		//close the scanner
		input.close();
	}
}