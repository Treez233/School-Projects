package tests;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.AnchorElement;
import model.ImageElement;
import model.ListElement;
import model.ParagraphElement;
import model.TableElement;
import model.TagElement;
import model.TextElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void testTables() {
		int indentation = 3;
		String attributes ="border=\"1\"", result= "";
		ParagraphElement pElem = new ParagraphElement(attributes);
		ListElement eElem = new ListElement(false, attributes);
		ImageElement IElem = new ImageElement("Student.img", 30, 40, "Student", attributes);
		pElem.addItem(eElem);
		pElem.addItem(IElem);
		TagElement.resetIds();
		TagElement.enableId(true);
		TableElement tableElement = new TableElement(2, 3, attributes);
		tableElement.addItem(0, 0, pElem);
		tableElement.addItem(0, 1, new TextElement("Laura"));
		tableElement.addItem(1, 0, new TextElement("Rose"));
		tableElement.addItem(1, 2, new TextElement("Josh"));
		
		result += tableElement.genHTML(indentation);
		System.out.println(result);
		
	}
	@Test
	public void pub04AnchorElementTest2() {

		int indentation = 3;
		String answer = "", attributes = "border=\"1\"";

		TagElement.resetIds();
		TagElement.enableId(false);
		AnchorElement element = new AnchorElement("http://www.cs.umd.edu", "UMD", attributes);
		answer += element.genHTML(indentation);
		answer += "\nSecondElement\n";

		element = new AnchorElement("http://www.cs.umd.edu", "UMD", attributes);
		answer += element.genHTML(indentation);

		answer += "\nThirdElement\n";
		indentation = 6;
		element = new AnchorElement("http://www.cs.umd.edu", "UMD", attributes);
		;
		answer += element.genHTML(indentation);

		System.out.println(answer);
	}

}
