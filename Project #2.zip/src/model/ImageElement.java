package model;

/**
 * Represents an &lt;img&gt; tag.  For this project
 * you can assume we will not update any of the attributes associated with
 * this tag.
 * @author UMCP
 *
 */
public class ImageElement extends TagElement {
	private String imageURL;
	private int width, height;
	private String alt;
	private String attributes;

	public ImageElement(String imageURL, int width, int height, String alt, String attributes) {
		//calling the constructor and initializing the dimensions and alt attribute
		super("img", true, null, attributes);
		this.imageURL = imageURL;
		this.width = width;
		this.height = height;
		this.alt = alt;
		this.attributes = attributes;

	}
	
	//get method for the url
	public String getImageURL() {
		return imageURL;
	}
	@Override
	public String genHTML(int indentation) {
		String HTML = "";
		
		//calling Utilities.spaces to format the HTML
		HTML += Utilities.spaces(indentation);

		//if ID is included
		if(inclusion == true) {
			//if else to check for attribute
			if(attributes == null || attributes.isBlank()) {
				//generate the HTML with the correct format
				HTML += "<img " + "id=" + '"' + getStringId() + '"' + " src=\"" +  imageURL + '"' + " width=\"" +
						width + '"' + " height=\"" + height + '"' + " alt=\"" + alt + '"' +">";
			}else {
				HTML += "<img " + "id=" + '"' + getStringId() + '"' + " src=\"" +  imageURL + '"' + " width=" +
						width + '"' + " height=\"" + height + '"' + " alt=\"" + alt + '"' + " " + attributes +">";
			}
		}else {
			//if ID is excluded
			if(attributes == null || attributes.isBlank()) {
				//generate the HTML with the correct format
				HTML += "<img " + "src=\"" +  imageURL + '"' + " width=\"" +
						width + '"' + " height=\"" + height + '"' + " alt=\"" + alt + '"' +">";
			}else {
				HTML += "<img " + "src=\"" +  imageURL + '"' + " width=" +
						width + '"' + " height=\"" + height + '"' + " alt=\"" + alt + '"' + " " + attributes +">";
			}
			
		}
		return HTML;
	}
}
