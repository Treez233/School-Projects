package model;

/**
 * 
 * Represents an HTML tag element (<&lt;p&gt;, &lt;ul&gt;, etc.).
 * Each tag has an id (ids start at 1).  By default the start tag
 * will have an id (e.g., <&lt;p id="a1"&gt;&lt;/p&gt;) when
 * the HTML for the tag is generated.  This can be disabled by
 * using enableId.
 * @author UMCP
 *
 */
public class TagElement implements Element {

	private String tagName;
	private boolean endTag;
	private Element content;
	private String attributes;
	private static int id = 0;
	private int currentId = 0;
	protected static boolean inclusion = false;
	
	public TagElement(String tagName, boolean endTag, Element content, String attributes) {
		//initialzie each variable with the parameter passed in
		this.tagName = tagName;
		this.endTag = endTag;
		this.content = content;
		this.attributes = attributes;
		//check if the inclusion has been enable or not
		if(inclusion == true) {
			//add one to id
			id++;
		}
		//assign id to the current element
		currentId = id;

	}
	//get method for id
	public int getId() {
		return id;
	}
	
	//returns the startTag with the id of the current Element
	public String getStringId() {
		return tagName + Integer.toString(currentId);
	}
	
	public String getStartTag() {
		//check if inclusion has been enabled
		if(inclusion == false) {//if not
			if(attributes == null || attributes.isBlank()) { //check if the attributes are null or blank
				return "<" + tagName + ">"; //return the tagname
			}else {
				return "<" + tagName + " " + attributes + ">"; //return the tagname and the attributes
			}
		}else { //inclusion has been enabled
			if(attributes == null || attributes.isBlank()) { //check for attributes
				return "<" + tagName +" id=\"" + getStringId() + "\"" + ">"; //return tagname, id
			}else {
				return "<" + tagName +" id=\"" + getStringId() + "\" " + attributes + ">"; //return tagname, id, and attributes
			}
		}
	}
	public String getEndTag() {
		if(endTag == true) {//if an endtag is needed
			return "</" + tagName +">"; //return the tag name with / in front
		}else {
			return "";//return an empty string
		}
	}
	public void setAttributes(String attributes) {
		this.attributes = attributes; //set the attributes with the attributes passed in
	}
	public static void resetIds() {
		id = 0; //reset the id to 0
	}
	public static void enableId(boolean choice) {
		inclusion = choice; //enable or disable inclusion
	}
	@Override
	public String genHTML(int indentation) {
		String HTML = "";
		HTML += Utilities.spaces(indentation);//format with indentation
		HTML += getStartTag() + content.genHTML(0) + getEndTag(); //add start tag as specified and content and endtag as specified
		return HTML;
	}
}