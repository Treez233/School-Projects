package model;

/**
 * Represents the &lt;a&gt; tag.
 * @author UMCP
 *
 */
public class AnchorElement extends TagElement {
	private String linkText;
	private String url;
	private String attri = "";

	public AnchorElement(String url, String linkText, String attributes){
		//calling super constructor with the parameters
		super("a", true, new TextElement(linkText), attributes);
		//initializing url
		this.url = url;
		//assigning the formatted hyperlink attribute
		attri += " href=\"" + url + "\"";
		//if else to check if the attribute passed in is empty or null
		if(attributes == null || attributes.isBlank()){
			super.setAttributes(attri);
		}else {
			super.setAttributes(attri + " " + attributes);
		}
		//initializing linktext
		this.linkText = linkText;
	}
	
	//get method for the linktext
	public String getLinkText() {
		return linkText;
	}
	
	//get method for the url
	public String getUrlText() {
		return url;
	}
	@Override
	public String genHTML(int indentation) {
		//calling super to generate the HTML line
		String HTML = super.genHTML(indentation);
		return HTML;
		
	}
}
