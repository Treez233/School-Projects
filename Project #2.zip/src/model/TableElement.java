package model;

/**
 * Represents the &lt;table&gt tag.
 * A two dimensional array is used to keep track of the Element objects of table.
 * @author UMCP
 *
 */
public class TableElement extends TagElement {
	private Element[][] items;
	private int rows, cols;
	public TableElement(int rows, int cols, String attributes) {
		//super constructor
		super("table", true, null, attributes);
		//initializing the rows and cols of the table
		this.rows = rows;
		this.cols = cols;
		//initializing the items 2d array
		items = new Element[this.rows][this.cols];
	}
	public void addItem(int rowIndex, int colIndex, Element item) {
		//check if the indices are out of bounds
		if(rowIndex >= rows || colIndex >= cols) {
		}else {
			//add the item to the correct indices
			items[rowIndex][colIndex] = item;
		}
		
	}
	public double getTableUtilization() {
		double totalSpaces, usedSpaces;
		totalSpaces = rows * cols; //calculate the total spaces in the 2d array
		usedSpaces = 0; // initialize the usedspace variable
		//nested for loop to check each space
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++){
				//if the item is not null add one to the usedspace
				if(items[i][j] != null){
					usedSpaces++;
				}
			}
		}
		//if the table does not have any spaces
		if(totalSpaces <= 0) {
			return 0;
		}else {
			//calculate the utilization by dividing the usedspace by totalspace and then times 100 to get the percentage
			return usedSpaces / totalSpaces * 100;
		}
		
		
	}
	@Override
	public String genHTML(int indentation) {
		String HTML = "";
		//indentation and start tag
		HTML += Utilities.spaces(indentation) + getStartTag() + "\n";
		//for loop to add each item to the HTML string
		for(int i = 0; i < rows; i++) {
			HTML += Utilities.defaultSpaces(2) + "<tr>";
			for(int j = 0; j < cols; j++){
				if(items[i][j] != null) {
					HTML += "<td>" + items[i][j].genHTML(0) + "</td>";
				}else {
					HTML +="<td>" + "</td>";
				}
			}
			//end tag for the rows
			HTML += "</tr>" + "\n";
		}
		//indentation and endtag for the element
		HTML += Utilities.spaces(indentation) + getEndTag();
		return HTML;
	}
}
