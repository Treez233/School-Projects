package model;

import java.util.ArrayList;

/**
 * Represents the &lt;ul&gt and the &lt;ol&gt; tags.
 * An ArrayList is used to keep track of the Element objects of the list.
 * @author UMCP
 *
 */
public class ListElement extends TagElement {
	private ArrayList<Element> items;
	public ListElement(boolean ordered, String attributes) {
		//calling super constructor and using ternary operation to determined if the list is ol or ul
		super(ordered == true? "ol" : "ul", true, null, attributes);
		//initialize the items arraylist
		items = new ArrayList<Element>();
	}
	public void addItem(Element item) {
		//add an item to the items arraylist
		items.add(item);
	}
	@Override
	public String genHTML(int indentation) {
		String HTML = "";
		//format indentations
		HTML = Utilities.spaces(indentation);
		//add the start tag
		HTML += getStartTag();
		//for each loop to add the items in the list
		for(Element item: items) {
			HTML += "\n" + Utilities.spaces(indentation +3) + "<li>" +
					"\n" + Utilities.defaultSpaces(2) + item.genHTML(indentation)+
					"\n" + Utilities.spaces(indentation + 3) + "</li>";
		}
		//adding the end tag
		HTML += "\n" + Utilities.spaces(indentation) + getEndTag();
		return HTML;
	}
}
