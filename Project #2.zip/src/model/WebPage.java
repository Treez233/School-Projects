package model;

import java.util.*;

/**
 * Represents a web page.  Web page elements are
 * stored in an ArrayList of Element objects.  A title
 * is associated with every page.  This class implements
 * the Comparable interface.  Pages will be compared
 * based on the title.
 * @author UMCP
 *
 */
public class WebPage implements Comparable<WebPage> {
	private ArrayList<Element> elements;
	private String title;
	public WebPage(String title) {
		//initialize the elements arraylist and title string
		elements = new ArrayList<Element>();
		this.title = title;
	}
	public int addElement(Element element) {
		//add an element to the elemetns array
		elements.add(element);
		//check if it is a tag element
		if(element instanceof TagElement) {
			//if so return its id
			return ((TagElement) element).getId();
		}else {
			//if not return -1
			return -1;
		}
	}
	public String getWebPageHTML(int indentation) {
		//creating a HTML variable and format it with the correct indentation and tags
		String HTML = "<!doctype html>\n" + "<html>\n";
		HTML += Utilities.defaultSpaces(1) + "<head>\n";
		HTML += Utilities.defaultSpaces(2) + "<meta charset=\"utf-8\"/>\n";
		HTML += Utilities.defaultSpaces(2) + "<title>" + title +"</title>\n" ;
		HTML += Utilities.defaultSpaces(1) + "</head>\n";
		HTML += Utilities.defaultSpaces(1) + "<body>\n";
		
		//adding each element to the webpage HTML
		for(Element elem : elements) {
			HTML += elem.genHTML(indentation) + "\n";
		}
		//indentation and end tag of the body and webpage
		HTML += "\n" + Utilities.defaultSpaces(1) + "</body>\n" + "</html>";
		return HTML;
	}
	public void writeToFile(String filename, int indentation) {
		//write to the file with the name specified and the correct indentation
		Utilities.writeToFile(filename, getWebPageHTML(indentation));
	}
	public Element findElem(int id) {
		//for each loop to check the id of the element
		for(Element elem : elements) {
			if(elem instanceof TagElement) {
				if(((TagElement) elem).getId() == id) {
					//if found the matching id return the element with that id
					return elem;
				}
			}
		}
		return null;
	}
	public String stats() {
		//keeping track of how many List, Paragraph and table elements that are present
		String stats = "";
		int counterL = 0, counterP = 0, counterT = 0;
		double	tUtil = 0;;
		for(Element elem : elements) {
			if(elem instanceof ListElement) {
				counterL++;
			}else if(elem instanceof ParagraphElement) {
				counterP++;
			}else if(elem instanceof TableElement) {
				counterT++;
			}

		}
		//get the total utilization of the tables present
		for(Element tElem : elements) {
			if(tElem instanceof TableElement) {
				tUtil += ((TableElement) tElem).getTableUtilization();
			}
		}
		//calculate the average
		tUtil = tUtil / counterT;
		
		//adding the stats to the stats string
		stats += "List Count: " + counterL + "\n" +
				 "Paragraph Count: " + counterP + "\n" +
				 "Table Count: " + counterT + "\n" + 
				 "TableElement Utilization: " + tUtil;
		return stats;
		
	}
	public int compareTo(WebPage webPage) {
		//compare the titles
		return title.compareTo(webPage.title);
	}
	public static void enableId(boolean choice) {
		//enable inclusion in the tagElement class
		TagElement.enableId(choice);
	}
}
