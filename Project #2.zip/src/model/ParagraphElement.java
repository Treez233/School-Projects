package model;

import java.util.ArrayList;

/**
 * 
 * Represents a paragraph (&lt;p&gt;) tag.  It relies on an
 * ArrayList in order to keep track of the set of Element objects
 * that are part of the paragraph.
 * @author UMCP
 *
 */
public class ParagraphElement extends TagElement {
	private ArrayList<Element> items;
	
	public ParagraphElement(String attributes) {
		//calling the super constructor
		super("p", true, null, attributes);
		//initializing the items arraylist
		items = new ArrayList<Element>();
	}
	public void addItem(Element item) {
		//add an item to the arraylist 
		items.add(item);
	}
	@Override
	public String genHTML(int indentation) {
		String HTML = "";
		//indentation and start tag
		HTML += Utilities.spaces(indentation) + getStartTag();
		//for each loop to add the items to the HTML String
		for(Element item: items) {
			//using the genHTML method associated with the item to generate the HTML
			HTML += "\n" + item.genHTML(indentation + 3);
		}
		//indentation and end tag
		HTML += "\n" + Utilities.defaultSpaces(1) + getEndTag();
		return HTML;
	}
}
