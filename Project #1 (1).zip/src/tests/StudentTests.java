package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import tubeVideosManager.*;


/**
 * 
 * You need student tests if you are asking for help during
 * office hours about bugs in your code. Feel free to use
 * tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void testaddVideoToDBTrue() {
		TubeVideosManagerInt manager = new TubeVideosManager();

		assertTrue(manager.addVideoToDB("Funny Video","https://www.youtube.com/embed/QQQQQQQQQQQQ",13,Genre.Comedy) == true);
	}
	
	/*@Test(expected = IllegalArgumentException.class)
	public void testaddVideoToDBFalse() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		
		manager.addVideoToDB("Funny Video","https://www.youtube.com/embed/QQQQQQQQQQQQ",-1,Genre.Comedy);


	}*/
	@Test
	public void testSearchVideos() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		manager.addVideoToDB("Funny Video0","https://www.youtube.com/embed/1",13,Genre.Comedy);
		manager.addVideoToDB("Funny Video0","https://www.youtube.com/embed/1",13,Genre.Educational);
		manager.addVideoToDB("Funny Video1","https://www.youtube.com/embed/1",13,Genre.Comedy);
		manager.addVideoToDB("Funny Video2","https://www.youtube.com/embed/2",16,Genre.Documentary);
		manager.addVideoToDB("Funny Video3","https://www.youtube.com/embed/3",13,Genre.Comedy);
		manager.addVideoToDB("Funny Video4","https://www.youtube.com/embed/4",17,Genre.Documentary);
		manager.addVideoToDB("Funny Video5","https://www.youtube.com/embed/5",13,Genre.Comedy);
		System.out.println(manager.searchForVideos("Playlist","Funny Video0",13,Genre.Comedy).toString());
		System.out.println(manager.searchForVideos("Playlist","Funny Video0",-1,null).toString());
		System.out.println(manager.searchForVideos("Playlist",null,13,null).toString());
		System.out.println(manager.searchForVideos("Playlist",null,-1,Genre.Comedy).toString());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testAddToPlaylist() {
		String str = null;
		Playlist list = new Playlist("myList");
		assertTrue(list.addToPlaylist(str) == false && list.addToPlaylist("Video") == true && list.addToPlaylist("") == false);
		
	}
	
	@Test
	public void testRemoveFromPlaylisyAll() {
		Playlist list = new Playlist("myList");
		list.addToPlaylist("Vid1");		
		list.addToPlaylist("Vid2");		
		list.addToPlaylist("Vid1");		
		list.addToPlaylist("Vid3");	
		System.out.println(list.toString());
		list.removeFromPlaylistAll("Vid1");
		System.out.println(list.toString());
		
	}
	
	@Test
	public void testFindVideos() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		manager.addVideoToDB("Funny Video0","https://www.youtube.com/embed/1",13,Genre.Educational);
		manager.addVideoToDB("Funny Video1","https://www.youtube.com/embed/1",13,Genre.Comedy);
		manager.addVideoToDB("Funny Video2","https://www.youtube.com/embed/2",16,Genre.Documentary);
		manager.addVideoToDB("Funny Video3","https://www.youtube.com/embed/3",13,Genre.Comedy);
		manager.addVideoToDB("Funny Video4","https://www.youtube.com/embed/4",17,Genre.Documentary);
		manager.addVideoToDB("Funny Video5","https://www.youtube.com/embed/5",13,Genre.Comedy);
		Video vid = new Video("Funny Video0","https://www.youtube.com/embed/1",13,Genre.Educational);
		
		assertTrue(vid.equals(manager.findVideo("Funny Video0")));
	}
	@Test
	public void testAddandGetComments() {
		ArrayList<String> cmt = new ArrayList<String>();
		cmt.add("Very funny I laughed");
		TubeVideosManagerInt manager = new TubeVideosManager();
		manager.addVideoToDB("Funny Video0","https://www.youtube.com/embed/1",13,Genre.Educational);
		manager.addComments("Funny Video0", "Very funny I laughed");
		ArrayList<String> str = manager.findVideo("Funny Video0").getComments();
		assertTrue(cmt.equals(str));
	}
	@Test
	public void testAddGetPlaylist() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		Playlist list = new Playlist("List 1");
		manager.addPlaylist("List 1");
		manager.addPlaylist("List 2");
		manager.addPlaylist("List 3");
		Playlist result = manager.getPlaylist("List 1");
		System.out.println(list.toString());
		System.out.println(result.toString());
		assertTrue(list.toString().equals(result.toString()) && manager.getPlaylist(null) == null);
		

	}
	@Test(expected = IllegalArgumentException.class)
	public void testAddPlaylistBadParameters() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		assertTrue(manager.addPlaylist(null) == false && manager.addPlaylist("") == false);
		
		
	}
	@Test//(expected = IllegalArgumentException.class)
	public void testGetPlaylistBadParameters() {
		TubeVideosManagerInt manager = new TubeVideosManager();
		assertTrue(manager.getPlaylist("") == null );
	}
}
