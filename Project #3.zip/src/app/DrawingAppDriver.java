package app;

import app.DrawingApp;
import java.util.Scanner;
public class DrawingAppDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		
		int maxRows = 6 , maxCols = 9 ;
		char symbol = '*';
		
		System.out.println(DrawingApp.getFlag(9,'R', '.', 'Y'));
		System.out.println(DrawingApp.getVerticalBars(10,1,1,'R', 'G', 'Y'));
	}

}
