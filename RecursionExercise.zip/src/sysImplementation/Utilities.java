package sysImplementation;

import java.util.ArrayList;

public class Utilities {

	public static String addDelimiter(String str, char delimeter) {
		String s = "";
		//base case: if theres is only one character in the string, return the string
		if (str.length() == 1) {
			return str;
		} else {
			//add the delimiter after the first char and recursively call the method without the first character of the string
			s = s + str.charAt(0) + delimeter + addDelimiter(str.substring(1), delimeter);
		}
		return s;
	}

	public static String getDigits(String str) {
		String s = "";
		if (str.isEmpty()) {//base case: if the string is empty return the string
			return str;
		} else if (Character.isDigit(str.charAt(0))) {//if the first character is a digit
			//concatenate the first character then recusively call the method without the first character
			s = s + str.charAt(0) + getDigits(str.substring(1));
		} else {
			//if the first char is not a digit call the string recursively
			s = s + getDigits(str.substring(1));
		}
		return s;
	}

	public static void replaceCharacter(char[] array, char target, char replacement) {
		replaceAux(array, target, replacement, 0);
	}

	private static void replaceAux(char[] array, char target, char replacement, int index) {
		if (index > array.length - 1) {//base case: if the index is bigger than the length -1 end the method
			return;
		} else if (array[index] == target) {//if the char at index is the target
			array[index] = replacement; //set the char to the replacement
			//call the method again at the index after the current index
			replaceAux(array, target, replacement, index + 1);
		} else {
			//call the method again at the index after the current index
			replaceAux(array, target, replacement, index + 1);
		}
	}

	public static int getSumEven(int[] array) {
		return sumEvenAux(array, 0);
	}

	private static int sumEvenAux(int[] array, int index) {
		int sum = 0;
		if (index > array.length - 1) { //base case if the index is bigger than the array length -1 return the sum
			return sum;
		} else if (array[index] % 2 == 0) {//check if the integer is even
			//add the integer at the current index and call the method recursively with the next index
			sum = array[index] + sumEvenAux(array, index + 1);
		} else {
			//call the method recursively with the next index
			sum = sumEvenAux(array, index + 1);
		}
		return sum;
	}

	public static ArrayList<Integer> getListRowIndices(int[][] array, int rowLength) {
		ArrayList<Integer> result = new ArrayList<Integer>(); //creating a new arrayList
		getListRowIndicesAux(result, array, rowLength, array.length - 1);
		return result;

	}

	private static void getListRowIndicesAux(ArrayList<Integer> result, int[][] array, int rowLength, int arraylength) {
		//we are recusively check the rows from the back to the front
		if (arraylength != 0) { //base case: if the array length is not 0
			getListRowIndicesAux(result, array, rowLength, arraylength - 1); // call the method with the array with its length -1
			if (array[arraylength].length == rowLength) {// if the row of the array is equal to the rowLength
				result.add(arraylength);//add the row number to the arrayList
			}
		} else {
			if (array[0].length == rowLength) {// if the first row has the rowLength
				//add the last row to the arrayList
				result.add(0);
			}
		}

	}

	private static boolean checkValid(char[][] array, int x, int y) {
		if (x >= 0 && x < array.length && y >= 0 && y < array[x].length) {
			return true;
		} else {
			return false;
		}
	}

	public static int replaceCells(char[][] array, int x, int y, char target, char replacement) {
		int count = 0;
		//if the indices are valid
		if (checkValid(array, x, y) == true) {//base case
			if (array[x][y] == target) {//if the cell is the target
				count = count + 1; //add one to the counter
				array[x][y] = replacement;
				
				//left and under cells
				count += replaceCells(array, x + 1, y, target, replacement);
				count += replaceCells(array, x - 1, y, target, replacement); 
				//up and under cells
				count += replaceCells(array, x, y + 1, target, replacement); 
				count += replaceCells(array, x, y - 1, target, replacement);
				//left under and right up cells
				count += replaceCells(array, x - 1, y - 1, target, replacement);
				count += replaceCells(array, x + 1, y + 1, target, replacement);
				//right under and left up cells
				count += replaceCells(array, x + 1, y - 1, target, replacement);
				count += replaceCells(array, x - 1, y + 1, target, replacement);

			}
		}
		return count;

	}
}
