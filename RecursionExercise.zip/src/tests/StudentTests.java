package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Test;
import sysImplementation.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class StudentTests {

	@Test
	public void test1() {
		String answer = "";

		String str = "fall";
		char delimeter = '*';
		answer += str + "  --->  " + Utilities.addDelimiter(str, delimeter) + "\n";
		System.out.println(answer);
	}

	@Test
	public void test2() {
		String answer = "";

		String str = "a2b3b4b512s";
		answer += str + "  --->  " + Utilities.getDigits(str) + "\n";
		System.out.println(answer);
	}

	@Test
	public void test3() {
		String answer = "";

		char[] array = { 'a', 'd', 'd', 'c', 'e', 'r', 'd', 'd' };
		Utilities.replaceCharacter(array, 'd', 'a');
		answer += Arrays.toString(array);
		System.out.println(answer);
	}

	@Test
	public void test4() {
		int sum = 0;

		int[] array = { 2, 3, 4, 5, 6, 7, 8 };

		sum += Utilities.getSumEven(array);
		;
		System.out.println(sum);
	}

	@Test
	public void test5() {
		String answer = "";
		int[][] twoDimArray = { { 4, 5 }, { 1, 2, 3, 4, 5, 6, 7, 10, 11, 14 }, { 2, 4, 6, 8 },
				{ 10, 21, 31, 45, 51, 62, 71, 12, 13, 14 } };
		int rowLength = 10;
		ArrayList<Integer> list = Utilities.getListRowIndices(twoDimArray, rowLength);
		answer += "\nIndices: " + list.toString();
		System.out.println(answer);
	}

	@Test
	public void test6() {
		String answer = "";
		char[][] charArray = { { 'R', 'B', 'B', 'Y', 'Y' }, { 'R', 'Y', 'R', 'B', 'Y' }, { 'R', 'M', 'B', 'Y', 'Y' },
				{ 'R', 'B', 'Y', 'Y', 'Y' }, { 'R', 'B', 'B', 'B', 'Y' }, { 'R', 'Y', 'R', 'B', 'P' }, };

		answer += "\nOriginal Array:\n" + printArray(charArray);
		int x = 1, y = 3;
		char target = 'B';
		char replacement = '&';
		Utilities.replaceCells(charArray, x, y, target, replacement);
		answer += "After processing: " + x + ", " + y + "\n" + printArray(charArray);
		System.out.println(answer);
	}
	private static String printArray(char [][]array) {
		StringBuffer answer = new StringBuffer();
		
		/* Notice how we can loop through the array */
		for (char[] row : array) {
			for (char entry : row) {
				answer.append(entry + " ");
			}
			answer.append("\n");
		}
		
		return answer.toString();
	}

}