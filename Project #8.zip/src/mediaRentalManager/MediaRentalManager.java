package mediaRentalManager;

import java.util.ArrayList;
import java.util.Collections;

public class MediaRentalManager implements MediaRentalManagerInt {
	ArrayList<Media> mediaInfo = new ArrayList<Media>();
	ArrayList<Customer> customerInfo = new ArrayList<Customer>();

	public void addCustomer(String name, String address, String plan) {
		Customer newCustomer = new Customer(name, address, plan);
		customerInfo.add(newCustomer);
	}

	public void addMovie(String title, int copiesAvailable, String rating) {
		Media newMovie = new Movies(title, copiesAvailable, rating);
		mediaInfo.add(newMovie);

	}

	public void addAlbum(String title, int copiesAvailable, String artist, String songs) {
		Media newAlbum = new MusicAlbums(title, copiesAvailable, artist, songs);
		mediaInfo.add(newAlbum);

	}

	public void setLimitedPlanLimit(int value) {
		for (Customer customer : customerInfo) {
			if (customer.getPlan() == "LIMITED") {
				customer.setLimit(value);
			}
		}
	}

	public String getAllCustomersInfo() {
		String s = "***** Customers' Information *****" + "\n";
		Collections.sort(customerInfo);
		for (Customer customer : customerInfo) {
			s += customer.toString() + "\n";
		}
		return s;
	}

	public String getAllMediaInfo() {
		String s = "***** Media Information *****" + "\n";
		Collections.sort(mediaInfo);
		for (Media media : mediaInfo) {
			s += media.toString() + "\n";
		}
		return s;
	}

	public boolean addToQueue(String customerName, String mediaTitle) {
		for (Customer customer : customerInfo) {
			if (customer.getName().equals(customerName)) {
				if (!customer.getQueued().contains(mediaTitle)) {
					customer.addQueue(mediaTitle);
					return true;
				} else {
					return false;
				}
			}

		}
		return false;
	}

	public boolean removeFromQueue(String customerName, String mediaTitle) {
		for (Customer customer : customerInfo) {
			if (customer.getName().equals(customerName)) {
				if (customer.getQueued().contains(mediaTitle)) {
					customer.removeQueue(mediaTitle);
					return true;
				} else {
					return false;
				}
			}

		}
		return false;
	}

	private int copiesAvailable(String title) {
		int copiesAvailable = 0;
		for (Media media : mediaInfo) {
			if (media.getTitle().equals(title)) {
				copiesAvailable = media.getCopies();
			}
		}
		return copiesAvailable;
	}

	private void rented(Customer customer, String queuedMedia) {
		customer.addRented(queuedMedia);
		for (Media media : mediaInfo) {
			if (media.getTitle().equals(queuedMedia)) {
				media.subtractCopies();
			}
		}
	}

	public String processRequests() {
		String message = "";
		Collections.sort(customerInfo);
		for (Customer customer : customerInfo) {
			if (customer.getPlan().equals("LIMITED")) {
				if (customer.getRented().size() < customer.getLimit()) {
					for (String queuedMedia : customer.getQueued()) {
						if (copiesAvailable(queuedMedia) > 0 &&customer.getRented().size() < customer.getLimit() ) {
							rented(customer, queuedMedia);
							customer.removeQueue(queuedMedia);
							message += "Sending " + queuedMedia + " to " + customer.getName() + "\n";
						}
					}
				}
			}
			if (customer.getPlan().equals("UNLIMITED")) {
				for (String queuedMedia : customer.getQueued()) {
					if (copiesAvailable(queuedMedia) > 0) {
						rented(customer, queuedMedia);
						customer.removeQueue(queuedMedia);
						message += "Sending " + queuedMedia + " to " + customer.getName() + "\n";
					}
				}
			}
		}
		return message;
	}

	public boolean returnMedia(String customerName, String mediaTitle) {
		for (Customer customer : customerInfo) {
			if (customer.getName().equals(customerName)) {
				customer.removeRented(mediaTitle);
				customer.setLimit(customer.getLimit() + 1);
			for (Media media : mediaInfo) {
				if (media.getTitle().equals(mediaTitle)) {
					media.addCopies();
				}
			}
			return true;
			}
		}
		return false;
	}

	public ArrayList<String> searchMedia(String title, String rating, String artist, String songs) {
		Collections.sort(mediaInfo);
		ArrayList<String> result = new ArrayList<String>();
		if (title == null && rating == null && artist == null && songs == null) {
			for (Media media : mediaInfo) {
				result.add(media.getTitle());
			}
			return result;
		} else {
			for (Media media : mediaInfo) {
				if (title != null && media.getTitle().equals(title)) {
					result.add(media.getTitle());
				}
				if (media instanceof Movies && rating != null && ((Movies) media).getRating().equals(rating)) {
					result.add(media.getTitle());
				}
				if (media instanceof MusicAlbums) {
					if (artist != null && ((MusicAlbums) media).getArtist().contains(artist)) {
						result.add(media.getTitle());
					}
					if (songs != null && ((MusicAlbums) media).getsongList().contains(songs)) {
						result.add(media.getTitle());
					}
				}
			}
			Collections.sort(result);
			return result;
		}

	}
}
