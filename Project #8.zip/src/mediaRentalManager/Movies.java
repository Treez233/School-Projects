package mediaRentalManager;

public class Movies extends Media{
	String rating;
	public Movies(String title, int copiesAvailable, String rating) {
		super(title, copiesAvailable);
		this.rating = rating;
	}
	public String getRating(){
		return rating;
	}
	public String toString() {
		String s = super.toString();
		return s+", Rating: " + getRating();
	}
		
}
