package mediaRentalManager;

public class Media implements Comparable<Media>{
	String title;
	int copiesAvailable;
	public Media(String title, int copiesAvailable) {
		this.title = title;
		this.copiesAvailable = copiesAvailable;
	}
	
	public String getTitle() {
		return title;
	}
	public int getCopies() {
		return copiesAvailable;
	}
	public void addCopies() {
		copiesAvailable++;
	}
	public void subtractCopies() {
		copiesAvailable--;
	}
	public int compareTo(Media media) {
		return this.title.compareTo(media.getTitle());
	}
	public String toString() {
		String s = "Title: " + getTitle() + ", " + "Copies Available: "+ getCopies();
		return s;
	}
}
