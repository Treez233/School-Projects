package mediaRentalManager;

public class MusicAlbums extends Media{
	String artist, songList;
	public MusicAlbums(String title, int copiesAvailable, String artist, String songList)   {
		super(title, copiesAvailable);
		this.artist = artist;
		this.songList = songList;
	}
	public String getArtist() {
		return artist;
	}
	public String getsongList() {
		return songList;
	}
	public String toString() {
		String s = super.toString();
		return s + ", Artist: " + getArtist() + ", Songs: " + getsongList();
	}
}
