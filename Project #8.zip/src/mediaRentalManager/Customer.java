package mediaRentalManager;

import java.util.ArrayList;

public class Customer implements Comparable<Customer>{
	String name,address,plan;
	int limit;
	ArrayList<String> queued;
	ArrayList<String> rented;
	
	public Customer(String name,String address,String plan) {
		this.name = name;
		this.address = address;
		this.plan = plan;
		if(plan.equals("LIMITED")) {
			limit = 2;
		}
		queued = new ArrayList<String>();
		rented = new ArrayList<String>();
		
	}
	public void addQueue(String title) {
		queued.add(title);
	}
	
	public void removeQueue(String title) {
		queued.remove(title);
	}
	
	public void addRented(String title) {
		rented.add(title);
	}
	public void removeRented(String title) {
		rented.remove(title);
	}
	public String getName() {
		return name;
	}
	public String getPlan() {
		return plan;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int newlimit) {
		limit = newlimit;
	}
	public ArrayList<String> getQueued(){
		ArrayList<String> copy = new ArrayList<String>(queued);
		return copy;
	}
	public ArrayList<String> getRented(){
		ArrayList<String> copy = new ArrayList<String>(rented);
		return copy;
	}
	
	public int compareTo(Customer customer) {
		int result = this.name.compareTo(customer.name);
		return result;
	}
	public String toString() {
		String s = "Name: "+ name + ", Address: " + address + ", Plan: " + plan + "\n" 
					+ "Rented: " + rented + "\n" +"Queue: " + queued;
		return s;
	}
}
