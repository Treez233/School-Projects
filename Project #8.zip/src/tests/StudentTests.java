package tests;

import static org.junit.Assert.*;

import org.junit.Test;
import mediaRentalManager.*;

public class StudentTests {

	@Test
	public void testAddToQueue() {
		MediaRentalManager manager = new MediaRentalManager();	
		manager.addCustomer("Smith, John", "354 South J Ave MD", "UNLIMITED");
		manager.addCustomer("Albert, Mike", "354 South J Ave MD", "LIMITED");
		manager.addCustomer("Poop, John", "354 South J Ave MD", "UNLIMITED");
		manager.addToQueue("Smith, John", "Jaws");
		manager.addToQueue("Albert, Mike", "Rocky");
		manager.addToQueue("Albert, Mike", "Bad");
		String s = manager.getAllCustomersInfo();
		System.out.println(s);
	}

}
