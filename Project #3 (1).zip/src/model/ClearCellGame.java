package model;

import java.util.Random;

/**
 * This class extends GameModel and implements the logic of the clear cell game.
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined as one
 * where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

public class ClearCellGame extends Game {
	private Random r;
	private int strategy;
	private int score;

	/**
	 * Defines a board with empty cells. It relies on the super class constructor to
	 * define the board. The random parameter is used for the generation of random
	 * cells. The strategy parameter defines which clearing cell strategy to use
	 * (for this project it will be 1). For fun, you can add your own strategy by
	 * using a value different that one.
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ClearCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols); // initialize the boardCell obj with the super constructor
		r = random; // initialize the random variable
		this.strategy = strategy; // set the strategy to the one passed in
		score = 0; // set the score to 0
	}

	/**
	 * The game is over when the last board row (row with index board.length -1) is
	 * different from empty row.
	 */
	public boolean isGameOver() {
		// for loop to check for any cell that is not empty in the last row
		for (int i = 0; i < this.getMaxCols(); i++) {
			if (this.getBoardCell(this.getMaxRows() - 1, i) != BoardCell.EMPTY) {
				// if any cell is not empty return true
				return true;
			}
		}
		return false;
	}

	public int getScore() {
		// return the score;
		return this.score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if the
	 * last board row (row with index board.length -1) corresponds to the empty row;
	 * otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		// check if the game is over or not
		if (isGameOver() == false) {
			// nested for loop to move every row down 1
			for (int i = this.getMaxRows() - 2; i >= 0; i--) {
				for (int j = 0; j < getMaxCols(); j++) {
					// if statement to skip every empty cell
					if (this.getBoardCell(i, j) != BoardCell.EMPTY) {
						this.setBoardCell(i + 1, j, this.getBoardCell(i, j));
					}
				}
			}
			// for loop to set the first row with random cells
			for (int i = 0; i == 0; i--) {
				for (int j = 0; j < this.getMaxCols(); j++) {
					this.setBoardCell(i, j, BoardCell.getNonEmptyRandomBoardCell(r));
				}
			}

		}
	}

	/**
	 * This method will turn to BoardCell.EMPTY the cell selected and any adjacent
	 * surrounding cells in the vertical, horizontal, and diagonal directions that
	 * have the same color. The clearing of adjacent cells will continue as long as
	 * cells have a color that corresponds to the selected cell. Notice that the
	 * clearing process does not clear every single cell that surrounds a cell
	 * selected (only those found in the vertical, horizontal or diagonal
	 * directions).
	 * 
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br />
	 * <br />
	 * 
	 * If after processing cells, any rows in the board are empty,those rows will
	 * collapse, moving non-empty rows upward. For example, if we have the following
	 * board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */

	public void processCell(int rowIndex, int colIndex) {
		// check if the game has ended
		if (!isGameOver()) {
			// check if the user clicked an empty cell
			if (board[rowIndex][colIndex] != BoardCell.EMPTY) {
				// store the cell the user clicked for later searches
				BoardCell targetCell = board[rowIndex][colIndex];
				// clear the cell the user clicked
				board[rowIndex][colIndex] = BoardCell.EMPTY;
				// add one to the score
				score++;

				// search up
				for (int i = rowIndex - 1; i >= 0; i--) {//start at the position up 1
														 //loop until it reaches the top row
					if (board[i][colIndex] == targetCell) {//check for the cell color
						board[i][colIndex] = BoardCell.EMPTY;//clear the cell
						score++;//add one to the score
					} else {
						break; //break out of the loop if the cell up one is not the target
					}
				}

				// search down
				for (int i = rowIndex + 1; i < getMaxRows() - 1; i++) {//start at the position down 1
																	   //loop until it reaches the second last row
					if (board[i][colIndex] == targetCell) {
						board[i][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}

				// left
				for (int i = colIndex - 1; i >= 0; i--) {//start at the position left 1
														 //loop until it reaches the leftmost column
					if (board[rowIndex][i] == targetCell) {
						board[rowIndex][i] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}

				// right
				for (int i = colIndex + 1; i < getMaxCols(); i++) {//start at postion right 1
																   //loop until it reaches the rightmost column
					if (board[rowIndex][i] == targetCell) {
						board[rowIndex][i] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}

				/*
				 * diagonal searches is easier with while loops so i switched to while loops
				 */
				// up left
				int up = rowIndex;//initialize the positions
				int left1 = colIndex;
				while (up > 0 & left1 > 0) {//check if the position is not at the border of the board
					if (board[--up][--left1] == targetCell) {//move to the position to up 1 left 1 and check for target
						board[up][left1] = BoardCell.EMPTY;//clears the cell if the cell is the same color
						score++; //add one to the score
					} else {
						break; //if not break out of the loop
					}
				}
				// up right
				up = rowIndex;//reset the positions
				int right1 = colIndex;
				while (up > 0 & right1 < getMaxCols() - 1) {
					if (board[--up][++right1] == targetCell) {
						board[up][right1] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// down right
				int down = rowIndex; //new variable name to avoid confusion
				int right2 = colIndex;
				while (down < getMaxRows() - 1 & right2 < getMaxCols() - 1) {
					if (board[++down][++right2] == targetCell) {
						board[down][right2] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// down left
				down = rowIndex;//reset the position
				int left2 = colIndex;
				while (down < getMaxRows() - 1 & left2 > 0) {
					if (board[++down][--left2] == targetCell) {
						board[down][left2] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}

			}
			collapseCell();//calling collapse cell method to collapse any empty rows
		}
	}

	private void collapseCell() {
		int targetRow = 0;
		//loop through the rows of the board to check for empty rows
		for (int row = 0; row <= getMaxRows() - 2; row++) {
			//if the rows are empty
			if (checkForEmptyRow(row)) {
				targetRow = row; //store the row number to targetRow
				//start at the target row and moves down
				for (int target = targetRow; target < getMaxRows() - 1; target++) {
					//loop through the columns and assign the cell under it up one
					for (int col = 0; col < getMaxCols(); col++) {
						board[target][col] = board[target + 1][col];
						board[target + 1][col] = BoardCell.EMPTY;
					}
				}
			}

		}

	}

	private boolean checkForEmptyRow(int rowIndex) {
		//method to check for empty rows
		int NumEmptyCols = 0;
		//check each column of the row passed in for empty cells
		for (int i = 0; i < getMaxCols(); i++) {
			if (board[rowIndex][i] == BoardCell.EMPTY) {
				//if the cell is empty add one to the counter
				NumEmptyCols++;
			}else {
				//if the cell is not empty return false;
				return false;
			}
		}
		//check if the number of empty cells match the total number of columns
		if (NumEmptyCols == getMaxCols()) {
			return true;//if it does return true;
		}
		return false;
	}
}