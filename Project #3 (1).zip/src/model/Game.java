package model;

import java.util.Arrays;

/**
 * This class represents the logic of a game where a board is updated on each
 * step of the game animation. The board can also be updated by selecting a
 * board cell.
 * 
 * @author Department of Computer Science, UMCP
 */

public abstract class Game {
	protected BoardCell[][] board;
	private int rows, cols;
	/**
	 * Defines a board with BoardCell.EMPTY cells.
	 * 
	 * @param maxRows
	 * @param maxCols
	 */
	public Game(int maxRows, int maxCols) {
		rows = maxRows;//initialize the rows
		cols = maxCols;//initialize the cols
		board = new BoardCell[rows][cols]; //initialize the board with a new two array
		for(int i = 0; i < maxRows; i++) {//using Arrays.fill to fill the board with empty cells
			for(int j = 0; j < maxCols; j++) {
				board[i][j] = BoardCell.EMPTY;
			}
		}

	}

	public int getMaxRows() {
		//return the number of rows
		return rows;
	}

	public int getMaxCols() {
		//return the number of cols
		return cols;
	}

	public void setBoardCell(int rowIndex, int colIndex, BoardCell boardCell) {
		//set the specific cell with the cell passed in
		this.board[rowIndex][colIndex] = boardCell;
	}

	public BoardCell getBoardCell(int rowIndex, int colIndex) {
		//return the specific cell
		return this.board[rowIndex][colIndex];
	}

	/**
	 * Initializes row with the specified color.
	 * 
	 * @param rowIndex
	 * @param cell
	 */
	public void setRowWithColor(int rowIndex, BoardCell cell) {
		//set the specific row with the cell passed in
		for(int i = 0; i < board[rowIndex].length; i++) {
			board[rowIndex][i] = cell;
		}
	}

	/**
	 * Initializes column with the specified color.
	 * 
	 * @param colIndex
	 * @param cell
	 */
	public void setColWithColor(int colIndex, BoardCell cell) {
		//set the specific column with the cell passed in
		for(int i = 0; i < getMaxRows() -1; i++) {
			board[i][colIndex] = cell;

		}
	}

	/**
	 * Initializes the board with the specified color.
	 * 
	 * @param cell
	 */
	public void setBoardWithColor(BoardCell cell) {
		//set the whole board with the cell color passed in
		for(int i = 0 ; i < board.length -1 ; i++) {
			for(int j = 0; j < board[i].length ; j++) {
				board[i][j] = cell;
			}
		}
	}

	public abstract boolean isGameOver();

	public abstract int getScore();

	/**
	 * Advances the animation one step.
	 */
	public abstract void nextAnimationStep();

	/**
	 * Adjust the board state according to the current board state and the selected
	 * cell.
	 * 
	 * @param rowIndex
	 * @param colIndex
	 */
	public abstract void processCell(int rowIndex, int colIndex);
}