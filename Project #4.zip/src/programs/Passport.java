package programs;

/**
 * This class represents a person's passport. It has three instance variables
 * representing the first, last and middle name (all are String variables). A
 * character instance variable representing a separator (to be used for
 * formatting purposes) is also part of the class. In addition, the class has a
 * StringBuffer instance variable that represents the passport stamps the person
 * has received.
 * 
 * For this class you need to define and use a private method called
 * validateAndFormat that takes a character as a parameter.
 * 
 * The class will keep track of the number of instances created by using a
 * private static field called objectCount.
 * 
 * @author CS
 *
 */
public class Passport {
	//private instance variables to store the information in object passport
	private String first, last, middle;
	private char separator;
	private StringBuffer stamps = new StringBuffer();
	//counter for the number of objects created
	private static int objectCount = 0;
	
	//constructor method with three parameters.
	public Passport(String firstname, String middlename, String lastname) {

		//setting the separator of the current object to the default ,
		this.separator = ',';
		
		//if the validateAndFormat doesn't return null
		if (validateAndFormat(firstname) != null) {
			//assign the first name in the current object with the formatted fristname parameter
			this.first = validateAndFormat(firstname);
		} else {
			//return and perform no further initialization
			return;
		}
		
		//if the middle name is not blank
		if (!(middlename.isBlank())) {
			//assign formatted middlename to the current object's middle name 
			this.middle = validateAndFormat(middlename);
		} else {
			//assign an empty string to the middle name 
			this.middle = "";
		}

		if (validateAndFormat(lastname) != null) {
			//assign formatted lastname to the current object's last name
			this.last = validateAndFormat(lastname);
			//adding 1 to the number of objects
			objectCount++;
		} else {
			return;
		}

	}
	//method that creates a string with firstname lastname and middlname(if any)
	public String toString() {
		//string variable to store all the information
		String answer;
		if (middle.isBlank()) {
			//if the middle name is blank only generate a string with first and last name
			answer = last + separator + first;
		} else {
			//generate the string with first last and middle name
			answer = last + separator + first + separator + middle;
		}
		return answer;
	}
	//constructor with two parameters
	public Passport(String firstname, String lastname) {
		//call the constructor with three parameters
		this(firstname, "", lastname);
	}
	//constructor with no parameters
	public Passport() {
		//calling the constructor with three paratmters and assigning them SAMPLEXXXX
		this("SAMPLEFIRSTNAME", "SAMPLEMIDDLENAME", "SAMPLELASTNAME");
	}
	//constructor with a passport object parameter
	public Passport(Passport passport) {
		/*calling the constructor with three parameters and send in 
		 * the instance variables of the object passed in
		 */
		
		this(passport.first, passport.last, passport.middle);
	}
	//method that adds a stamp to the stamps StringBuffer
	public Passport addStamp(String stamp) {
		//if the string passed in is empty or null
		if (stamp.isBlank() || stamp.equals(null)) {
			//return the reference to the current object
			return this;
		} else {
			//append the stamp string to the stamps StringBuffer
			this.stamps.append(stamp);
			//return the current object
			return this;
		}
	}
	//method that creates a copy of stamps
	public StringBuffer getStamps() {
		//creating a temp StringBuffer and initialized using the stamps StringBuffer
		StringBuffer temp = new StringBuffer(stamps);
		return temp;
	}
	//method that returns a separator
	public char getSeparator() {
		return separator;

	}
	//method to update the separator
	public boolean setSeparator(char separator) {
		//if the separator is invalid
		if (Character.isSpaceChar(separator) || separator == '@' || Character.isLetter(separator)) {
			//Don't update the separator and return false
			return false;
		} else {
			//update the separator and return true;
			this.separator = separator;
			return true;
		}
	}
	//method to test if two	passport objects are equal
	public boolean equals(Object obj) {
		//create a temporary passport object and initialze it with the object passed in
		Passport temp = (Passport) obj;
		//test if they are equal to each other
		if (temp.first.trim().equals(this.first) && temp.last.trim().equals(this.last)
				&& temp.middle.trim().equals(this.middle)) {
			//if they are equal return true
			return true;
		} else if (temp == null || temp.getClass() != this.getClass()) {
			//if the class of two objects are different or the object is null return false
			return false;
		} else {
			return false;
		}
	}
	//method that compares two objects
	public int compareTo(Passport passport) {
		//comparing the current object to the object passed in
		if (this.last.compareTo(passport.last) == 0) {
			if (this.first.compareTo(passport.first) == 0) {
				if (this.middle.compareTo(passport.middle) == 0) {
					//if they are all equal return 0
					return 0;
				} else {
					//returns the int value generated by the compareTo method 
					return this.middle.compareTo(passport.middle);
				}
			} else {
				//returns the int value generated by the compareTo method
				return this.first.compareTo(passport.first);
			}
		} else {
			//returns the int value generated by the compareTo method
			return this.last.compareTo(passport.last);
		}
	}
	//method that returns the number of objects created
	public static int getNumberOfPassportObjects() {
		return objectCount;
	}
	//reset the number of objects to zero
	public static void resetNumberOfPassportObjects() {
		objectCount = 0;
	}
	//method to normalize all the instance variables in passport object
	public static Passport normalize(Passport passport, boolean uppercase) {
		//create a new Passport object initialized it with the passport object passed in
		Passport normalized = new Passport(passport);
		//if the passport object is null return null
		if (passport == null) {
			return null;
		} else if (uppercase) { //else if the upper case is true capitalize all the variables 
			normalized.first = passport.first.toUpperCase();
			normalized.last = passport.last.toUpperCase();
			normalized.middle = passport.middle.toUpperCase();

		} else { //if the upper case is not true convert all the variables to lower case
			normalized.first = passport.first.toLowerCase();
			normalized.last = passport.last.toLowerCase();
			normalized.middle = passport.middle.toLowerCase();
		}
		//set the separator of normalized to the one passed in
		normalized.setSeparator(passport.separator);
		//return the object
		return normalized;
	}
	//method to changed the last name of the current Passport object
	public boolean changeLastname(String lastname) {
		//boolean variable to determine whether the last name variable has been changed or not
		boolean changed = false;
		//if the last name passed in is not null according to the validateAndFormat method
		if (validateAndFormat(lastname) != null) {
			//assign the current object's last name variable to the one passed in
			this.last = validateAndFormat(lastname);
			changed = true; //because the last name variable changed we set changed to true
			//return changed
			return changed;
		} else {
			return changed;
		}
	}

	/*
	 * This method will generate and return a formatted string in lowercase with the
	 * first character in uppercase. The parameter is valid if it is not null and it
	 * is not blank according to the string method isBlank(). If the parameter is
	 * invalid, the method will return null and perform no further processing. If
	 * the parameter is valid, spaces surrounding the parameter will be removed, the
	 * string will be converted to lowercase, and the first character of the string
	 * (after spaces have been removed) will be in upper case. The following methods
	 * can be helpful during the implementation of this method:
	 * Character.toUpperCase, and the string methods charAt and substring.
	 * 
	 * You can test this method by initially defining it public; once you have
	 * tested it, make it private.
	 * 
	 */
	private static String validateAndFormat(String name) {
		String nameFormatted;
		// if the name is not empty or null
		if (!(name.isBlank()) && !(name.equals(null))) {
			//get rid of empty space around the name and then convert the string to lowercase
			nameFormatted = name.trim().toLowerCase();
			//capitalized the first letter of the string
			nameFormatted = nameFormatted.substring(0, 1).toUpperCase() + nameFormatted.substring(1);
		} else {
			//if the name string is empty or null 
			return null;
		}
		//return the formatted string
		return nameFormatted;
	}
}