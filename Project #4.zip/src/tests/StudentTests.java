package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import programs.Passport;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	/*
	 * Each method in a JUnit StudentTest class represents a test. You can write
	 * code in a method of this class as you do in the main method of a driver. As
	 * you write your code, define methods in this class that test each of the
	 * methods you need to implement. When you run a method you can have
	 * System.out.println statements to see the results of your code. Using this
	 * approach is simpler than defining driver classes.
	 * 
	 * For this project you don't need to worry about adding assertions (we will
	 * talk about them soon). If you don't add assertions, by default, every test
	 * will pass (so when you run your student tests you will see a green bar). We
	 * have left two examples of tests below so you can see how you can test your
	 * code.
	 * 
	 * You can run a single test (e.g., testingtoString() below) by double-clicking
	 * on the method's name and selecting Run-->Run As-->JUnit Test. You can also
	 * double-click on the method's name and select the white triangle that is
	 * inside of a green circle (under Navigate menu entry).
	 */
	@Test
	public void testingPassport01() {
		Passport p1 = new Passport("Lucy", "S.", "Liu");
		System.out.println(p1);

	}//testing the constructor with three parameters

	@Test
	public void testingPassport02() {
		Passport p1 = new Passport("Lucy", "Liu");
		System.out.println(p1);

	}//testing the constructor with two parameters

	@Test
	public void testingPassport03() {
		Passport p1 = new Passport();
		System.out.println(p1);

	}//testing the constructor with no parameters

	@Test
	public void testingtoString() {
		Passport passport1 = new Passport("Rose", "I.", "Sanders");
		Passport passport2 = new Passport("Bernie", "", "Sanders");
		Passport passport3 = new Passport();
		System.out.println(passport1);
		System.out.println(passport2);
		System.out.println(passport3);
	}//testing toStirng method

	@Test
	public void testingAddStampAndGetStamp() {
		Passport p1 = new Passport("Bernie", "", "Sanders");
		Passport p2 = new Passport("Traveling", "Bernie");
		p1.addStamp("HongKong").addStamp("").addStamp("Tokyo");
		System.out.println(p1);
		System.out.println(p1.getStamps());
		p2.addStamp("");
		System.out.println(p2);
		System.out.println(p2.getStamps());
	}//testing the addStamp and getStamp methods

	@Test
	public void testingSetSeparator() {
		Passport passport1 = new Passport("Tom", "Johnson");
		System.out.println(passport1);

		passport1.setSeparator('#');
		System.out.println(passport1);
		passport1.setSeparator('@');
		System.out.println(passport1);
	}//testing the set separator method
	
	@Test
	public void testingEquals() {
		Passport p1 = new Passport("Bernie", "", "Sanders");
		Passport p2 = new Passport("Bernie", "", "Sanders");
		Passport p3 = new Passport("Traveling", "Bernie");
		System.out.println("Is p1 and p2 equal: " + p1.equals(p2));

		System.out.println("Is p1 and p3 equal: " + p1.equals(p3));
	}//testing the equals methods

	@Test
	public void testingCompareTo() {
		Passport p1 = new Passport("Bernie", "", "Sanders");
		Passport p2 = new Passport("Bernie", "", "Sanders");
		Passport p3 = new Passport("Traveling", "Bernie");
		System.out.println("Is p1 greater than p2: " + (p1.compareTo(p2) > 0));
		System.out.println("p1 = p2?: " + (p1.compareTo(p2) == 0));
		System.out.println("Is p3 bigger than p1: " + (p3.compareTo(p1) < 0));
	}//testing the compareTo methods
	
	@Test
	public void testingObjectCount() {
		Passport p1 = new Passport("Bernie", "", "Sanders");
		Passport p2 = new Passport("Bernie", "", "Sanders");
		Passport p3 = new Passport();
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		System.out.println(Passport.getNumberOfPassportObjects());
		Passport.resetNumberOfPassportObjects();
		System.out.println(Passport.getNumberOfPassportObjects());
		
	}//testing the object count method and the reset methods
	
	@Test
	public void testingNormalize() {
		Passport p1 = new Passport("BeRnie", "ThEGReAtEst", "SANDERS");
		System.out.println(p1);
		System.out.println(Passport.normalize(p1, true));
		p1.setSeparator('\\');
		System.out.println(Passport.normalize(p1, false));
	}//testing normalize method
	
	@Test
	public void testingChangeLastName() {
		Passport p1 = new Passport("Bernie", "", "Sanders");
		p1.changeLastname("Madoff");
		System.out.println(p1);
	}//test changing lastname method
	
	/*@Test
	public void testingValidateAndFormat() {
		Passport p1 = new Passport("berNIe", "", "sanDers");
		Passport.validateAndFormat("berNIe");
		System.out.println(p1);
	}*/ //testing validate and format method

}