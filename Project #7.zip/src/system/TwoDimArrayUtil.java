package system;

public class TwoDimArrayUtil {
	public static boolean isRagged(char[][] array) {
		boolean flag = false;
		int firstrow = 0;
		for (int row = 0; row < array.length; row++) {
			if (firstrow == 0) {
				firstrow = array[row].length;
			} else if (firstrow == array[row].length) {
				continue;
			} else {
				return flag = true;
			}
		}
		return flag;
	}

	public static void rotateTopOneRow(char[][] array) {
		if (array == null || TwoDimArrayUtil.isRagged(array) == true) {
			throw new IllegalArgumentException();
		}
		char[] temprow = array[0];
		int row;
		for (row = 0; row < array.length - 1; row++) {
			array[row] = array[row + 1];
		}
		array[row] = temprow;
	}

	public static void rotateLeftOneColumn(char[][] array) {
		if (array == null || TwoDimArrayUtil.isRagged(array) == true) {
			throw new IllegalArgumentException();
		}
		if (array[0].length != 1) {
			int row, col;
			char temp = '\0';
			for (row = 0; row <= array.length - 1; row++) {
				for (col = 0; col < array[row].length - 1; col++) {
					temp = array[row][col];
					array[row][col] = array[row][col + 1];
					array[row][col + 1] = temp;
				}

			}
		}
	}

	public static char[][] appendTopBottom(char[][] top, char[][] bottom) {
		char[][] product = new char[top.length + bottom.length][];
		int i, j;
		for (i = 0; i < top.length; i++) {
			product[i] = top[i];
		}
		for (j = 0; j < bottom.length; j++) {
			product[i++] = bottom[j];
		}
		return product;
	}

	public static char[][] appendLeftRight(char[][] left, char[][] right) {
		int rows;
		if (left.length > right.length) {
			rows = left.length;
		} else {
			rows = right.length;
		}
		char[][] product = new char[rows][];
		int i, j;
		
		for (i = 0; i < rows; i++) {
			if(left.length <= i) {
				product[i] = new char[right[i].length];
				for(j = 0; j < right[i].length; j++) {
					product[i][j] = right[i][j];
				}
			}else if(right.length <= i) {
				product[i] = new char[left[i].length];
				for(j = 0; j < left[i].length; j++) {
					product[i][j] = left[i][j];
				}
			}else {
				product[i] = new char[right[i].length+left[i].length];
				for(j = 0; j < left[i].length; j++) {
					product[i][j] = left[i][j];
				}
				for(j = 0; j < right[i].length; j++) {
					product[i][left[i].length + j] = right[i][j];
				}
			}
			
		}
		
		return product;
	}
}
