package system;

public class CombineLeftRight implements Diagram{
	int animationType;
	char[][] board;
	public CombineLeftRight(Diagram left, Diagram right, int animationType) {
		if(left.getBoard().length != right.getBoard().length) {
			throw new IllegalArgumentException();
		}
		this.animationType = animationType;
		board = TwoDimArrayUtil.appendLeftRight(left.getBoard(), right.getBoard());
	}
	public char[][] getBoard() {
		return board;
	}

	public char[][] nextAnimationStep() {
		char [][] updated = board;
		if (animationType == 1) {
			TwoDimArrayUtil.rotateLeftOneColumn(updated);
			return updated;
		} else if (animationType == 2 ) {
			TwoDimArrayUtil.rotateTopOneRow(updated);
			return updated;
		}else {
			return updated;
		}
	}

	public int getNumberRows() {
		return board.length;
	}

	public int getNumberCols() {
		return board[0].length;
	}
}
