package system;

public class CombineTopBottom implements Diagram{
	int animationType;
	char[][] board;
	public CombineTopBottom(Diagram top, Diagram bottom, int animationType) {
		for(int i = 0; i < top.getBoard().length; i++) {
		if(top.getBoard()[i].length != bottom.getBoard()[i].length) {
			throw new IllegalArgumentException();
		}
		}
		this.animationType = animationType;
		board = TwoDimArrayUtil.appendTopBottom(top.getBoard(), bottom.getBoard());
	}
	public char[][] getBoard() {
		return board;
	}

	public char[][] nextAnimationStep() {
		char [][] updated = board;
		if (animationType == 1) {
			TwoDimArrayUtil.rotateLeftOneColumn(updated);
			return updated;
		} else if (animationType == 2 ) {
			TwoDimArrayUtil.rotateTopOneRow(updated);
			return updated;
		}else {
			return updated;
		}
	}

	public int getNumberRows() {
		return board.length;
	}

	public int getNumberCols() {
		return board[0].length;
	}
}
