package app;

import java.util.Random;

public class DrawingApp {
	/*
	 * For every method remove the line with "throw ..." and implement the method.
	 * We are using "throw..." so your code does not display any compilation errors
	 * when you import the zip file. Also, if you don't implement a method you will
	 * see a white square (instead of green) in the submit server
	 */
	// method for display a rectangle
	public static String getRectangle(int maxRows, int maxCols, char symbol) {
		// creating temporary variables
		int tempRows = maxRows, tempCols = maxCols;
		char tempSymbol = symbol;
		// new string variable to store the entire diagram
		String rec = new String();

		// for loop to draw a rectangle
		for (int i = 1; i <= tempRows; i++) {
			for (int j = 1; j <= tempCols; j++) {
				rec += tempSymbol;
			}
			// add a new line character at the end of each row
			rec = rec + '\n';
		}
		// remove the last \n character
		if(rec.length() != 1) {
			rec = rec.trim();
		}else {
			String emptyString = "";
			return emptyString;
		}
		// return the string that stores the diagram
		return rec;
	}

	// method to print out a flag
	public static String getFlag(int size, char color1, char color2, char color3) {
		/* for this method i split the flag into two parts */
		// string variable that stores the two parts combined
		String flagCombined;
		// creating the two strings and initializing them
		String flag1 = "", flag2 = "";

		// if the size the user past in is less than 3 return null
		if (size < 3) {
			return null;
		} else {

			/*
			 * for loop for the rows, since i split the flag into two parts this part only
			 * loops ((size *2) / 2) = size
			 */
			// first half of the diagram
			for (int i = 1; i <= size; i++) {
				// for loop for the triangle
				for (int j = 1; j <= i; j++) {
					// add color1 to the appropriate amount of columns
					flag1 += color1;
				}
				// for loop for the rest of the columns
				for (int k = i; k <= size * 5 - 1; k++) {
					/* -1 because i was printing 1 extra column */
					if (i == 1 || i == size) {
						// if it is the first row or the last row use color 2
						flag1 += color2;
					} else {
						// anything else use color 3
						flag1 += color3;
					}
				}
				// add a new line character to the end of the line
				flag1 += '\n';
			}

			// second half of the diagram
			// for loop for the number of rows
			for (int i = 1; i <= size; i++) {
				// for loop for the upside down triangle
				for (int j = size; j >= i; j--) {
					// j starts at size(example: 9) and goes down by 1 each row 
					//until it is equal to 1
					// add the color1 to the appropriate amount of columns
					flag2 += color1;
				}
				/*
				 * for loop for the rest of the columns k starts at one and stops at the bound
				 * 
				 * size * 5 - (size - i) is because as k increases if we don't 
				 * decrease the bound it will print more columns than it needs to
				 * 
				 * (size - i) because each row the number of symbol for the triangle decreases 
				 * so there is more columns to fill
				 * 
				 *  -1 because i was printing an extra column
				 */
				for (int k = 1; k <= size * 5 - (size - i) - 1; k++) {
					//if else statement for first and last row
					if (i == 1 || i == size) {
						flag2 += color2;
					} else {
						flag2 += color3;
					}

				}
				//add a new line character
				flag2 += '\n';
			}
		}
		//remove the \n on last line
		flag2 = flag2.trim();
		//combine the two parts and remove any white space
		flagCombined = (flag1 + flag2).trim();
		//return
		return flagCombined;
	}

	//method for the diagram that prints out bars horizontally
	public static String getHorizontalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		//temporary variables
		int tempRows = maxRows, tempCols = maxCols, tempBars = bars;
		char tempC1 = color1, tempC2 = color2, tempC3 = color3;
		int barSize = tempRows / tempBars;
		//new string variable to store the diagram
		String horizontalBar = new String();
		
		//if the color past in is valid do....
		if (isValidColor(tempC1) == true && isValidColor(tempC2) == true && isValidColor(tempC3) == true
				&& barSize >= 1) {
			//counter for the number of bars, it increases every time a bar is complete
			int counter = 1;
			do {// do while loop to print the appropriate number of bars
				for (int i = 1; i <= barSize; i++) {
					// for loop to loop the appropriate time to the size of each bar
					for (int j = 1; j <= tempCols; j++) {
						//for loop for each columns in each bar
						if (counter != 1 && counter != 2 && counter != 3) {
							// if the counter for the number of bars is not 1, 2 or 3
							//reset the counter to 1
							counter = 1;
						}
						//assign appropriate colors
						if (counter == 1) {
							horizontalBar += tempC1;
						} else if (counter == 2) {
							horizontalBar += tempC2;
						} else if (counter == 3) {
							horizontalBar += tempC3;
						}

					}
					//add a new line
					horizontalBar += '\n';
				}
				//decrease the number of bars by 1
				tempBars--;
				//increase the counter by 1
				counter++;
			} while (tempBars != 0);
		} else {
			return null;
		}
		//remove the \n at the last line
		horizontalBar = horizontalBar.trim();
		//return the string
		return horizontalBar;
	}

	public static String getVerticalBars(int maxRows, int maxCols, int bars, char color1, char color2, char color3) {
		// create temporary variables
		int tempRows = maxRows, tempCols = maxCols, tempBars = bars;
		char tempC1 = color1, tempC2 = color2, tempC3 = color3;
		int barSize = tempCols / tempBars;
		String verticalBar = new String();
		// if else statement to do input validation
		if (isValidColor(tempC1) == true && isValidColor(tempC2) == true && isValidColor(tempC3) == true
				&& barSize >= 1) {
			// counter variable to rotate the symbols
			int counter = 1;
			//for loop for the number of rows
			for (int i = 1; i <= tempRows; i++) {
				//for loop for the columns
				for (int j = 1; j <= tempBars; j++) {
					//for loop for each bar in their respective columns
					for (int k = 1; k <= barSize; k++) {
						if (counter != 1 && counter != 2 && counter != 3) {
							// reset the counter if it is not 1 or 2 or 3
							counter = 1;
						}
						if (counter == 1) {
							verticalBar += tempC1;
						} else if (counter == 2) {
							verticalBar += tempC2;
						} else if (counter == 3) {
							verticalBar += tempC3;
						}
					}
					// increase the counter to rotate the symbol
					counter++;

				}
				// reset after the column is done
				counter = 1;
				// add a \n character
				verticalBar += '\n';

			}

		} else {
			// if the colors are not valid return null
			return null;
		}
		// remove the new line character
		verticalBar = verticalBar.trim();
		return verticalBar;
	}

	public static char getRandomColor(Random random) {
		final int bound = 6;
		//bound is 6 to produce a number from 0-5
		int tempNum = random.nextInt(bound);
		char tempSymbol = '\0';
		//assign a color to each appropriate symbol
		if (tempNum == 0) {
			tempSymbol = 'R';
		} else if (tempNum == 1) {
			tempSymbol = 'G';
		} else if (tempNum == 2) {
			tempSymbol = 'B';
		} else if (tempNum == 3) {
			tempSymbol = 'Y';
		} else if (tempNum == 4) {
			tempSymbol = '*';
		} else if (tempNum == 5) {
			tempSymbol = '.';
		}
		return tempSymbol;
	}

	private static boolean isValidColor(char color) {

		boolean flag = false;
		char temp = color;
		//if else statement for the validation
		if (temp == 'R' || temp == 'G' || temp == 'B' || temp == 'Y' || temp == '*' || temp == '.') {
			flag = true;
		} else {
		}

		return flag;
	}
}