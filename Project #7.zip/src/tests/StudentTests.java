package tests;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

import system.TwoDimArrayUtil;
public class StudentTests {
	private static String getTwoDimArrayString(char[][] array) {
		if (array == null) {
			throw new IllegalArgumentException("Invalid parameter getTwoDimArrayString()");
		}

		String answer = "";
		for (int row = 0; row < array.length - 1; row++) {
			answer += Arrays.toString(array[row]) + "\n";
		}
		answer += Arrays.toString(array[array.length - 1]);

		return answer;
	}
	@Test
	public void testisRagged() {
		char[][] array = {{'G','G','B','G','R'},{'G','G','G'},{'B','G','R','R','R','R','R'}};
		char[][] array2 = {{'G','G','B'},{'G','G','G'},{'B','G','R'}};
		assertTrue(TwoDimArrayUtil.isRagged(array) == true && TwoDimArrayUtil.isRagged(array2) == false);
	}
	
	@Test
	public void testRotateTopOneRow() {
		char[][] array = {{'G','G','B'},{'G','G','G'},{'B','G','R'}};
		char[][] expected ={{'B','G','R'},{'G','G','B'},{'G','G','G'}};
		TwoDimArrayUtil.rotateTopOneRow(array);
		TwoDimArrayUtil.rotateTopOneRow(array);
		String s1 = Arrays.deepToString(array);
		String s2 =Arrays.deepToString(expected);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	public void testRotateLeftOneColumn() {
		char[][] array = {{'G','R','B'},{'G','B','R'},{'B','G','R'}};
		char[][] expected ={{'R','B','G'},{'B','R','G'},{'G','R','B'}};
		TwoDimArrayUtil.rotateLeftOneColumn(array);
		//TwoDimArrayUtil.rotateLeftOneColumn(array);
		String s1 = Arrays.deepToString(array);
		String s2 =Arrays.deepToString(expected);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	public void testAppendTopBottom() {
		char[][] top = {{'G','G'},{'G','G','R'},{'B','G'}};
		char[][] bottom ={{'B','G','G'},{'G','G'},{'G','G'}};
		char[][] result = TwoDimArrayUtil.appendTopBottom(top, bottom);
		char[][] expected = {{'G','G'},{'G','G','R'},{'B','G'},{'B','G','G'},{'G','G'},{'G','G'}};
		String s1 = getTwoDimArrayString(result);
		String s2  = getTwoDimArrayString(expected);
		System.out.println(s1+"\n");
		System.out.println(s2);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	public void testAppendLeftRight() {
		char[][] left = {{'B','G'},{'G','G','R'},{'Y','B'}};
		char[][] right ={{'B','G'},{'G','G'}};
		char[][] result = TwoDimArrayUtil.appendLeftRight(left,right);
		char[][] expected = {{'B','G','B','G'},{'G','G','R','G','G'},{'Y','B'}};
		String s1 = getTwoDimArrayString(result);
		String s2 =getTwoDimArrayString(expected);
		System.out.println(s1+"\n");
		System.out.println(s2);
		assertTrue(s1.equals(s2));
	}
	
	@Test
	public void testFlag() {
		char[][] left = {{'B','G'},{'G','G','R'},{'G','R'}};
		char[][] right ={{'B','G'},{'G','G'},{'R','G','G'}};
		char[][] result = TwoDimArrayUtil.appendLeftRight(left,right);
		char[][] expected = {{'G','G','B','G'},{'G','G','R','G','G'},{'G','R','G','G','G'}};
		String s1 = getTwoDimArrayString(result);
		String s2 =getTwoDimArrayString(expected);
		System.out.println(s1+"\n");
		System.out.println(s2);
		assertTrue(s1.equals(s2));
	}

}         
